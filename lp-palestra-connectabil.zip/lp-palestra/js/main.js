/* =========================================================
   Connectabil — LP Palestra Vitória Oliveira
   - Seleção de benefício (apenas 1) sincronizada entre cards e formulário
   - Validação, máscara de telefone, captura de UTMs
   - Envio para RD Station (API de Conversões) ou webhook
   - Eventos de tracking em window.dataLayer (GTM/GA4) e Meta Pixel
   ========================================================= */
(function () {
  'use strict';

  /* =======================================================
     CONFIGURAÇÃO — preencher antes de publicar.
     Nenhuma credencial foi inventada: os valores abaixo são
     placeholders e o envio fica em modo "demo" até serem trocados.
     ======================================================= */
  var CONFIG = {
    /*
      mode:
        "demo"    → não envia nada; registra no console e mostra a tela de sucesso (para testes)
        "rd_api"  → envia direto para a API de Conversões do RD Station Marketing
        "webhook" → envia JSON para uma URL sua (Zapier, Make, n8n, Supabase Edge Function…),
                    que repassa para o RD Station
    */
    mode: 'demo',

    // RD Station Marketing → Configurações → Integrações → "Token público" (API key pública)
    rdPublicToken: 'COLE_AQUI_O_TOKEN_PUBLICO_DO_RD',
    rdEndpoint: 'https://api.rd.services/platform/conversions?api_key=',

    // Identificador da conversão que aparecerá no RD (pode ser alterado)
    conversionIdentifier: 'lp-reboot-contabil-2026',

    // Usado quando mode = "webhook"
    webhookUrl: 'COLE_AQUI_A_URL_DO_WEBHOOK',

    /*
      Mapeamento: name do campo na LP → identificador no RD Station.
      Campos padrão do RD: name, job_title, company_name, mobile_phone, email, city, state.
      Campos personalizados precisam ser criados no RD (Configurações → Campos personalizados)
      com os identificadores abaixo (o RD usa o prefixo "cf_").
    */
    rdFieldMap: {
      nome: 'name',
      cargo: 'job_title',
      empresa: 'company_name',
      telefone: 'mobile_phone',
      email: 'email',
      quantidade_funcionarios: 'cf_quantidade_funcionarios',
      cidade: 'city',
      estado: 'state',
      beneficio_escolhido: 'cf_beneficio_escolhido'
    }
  };

  var BENEFICIOS = {
    banco_talentos: '30 dias gratuitos de acesso ao maior banco de talentos contábil do Brasil',
    avaliacao_desempenho: '1 avaliação de desempenho completa do time da sua empresa',
    nr1: '1 diagnóstico + plano de ação de NR-1'
  };

  /* ---------- EVENTOS (GTM / GA4 / Meta Pixel) ---------- */
  window.dataLayer = window.dataLayer || [];
  function track(event, params) {
    var data = Object.assign({ event: event }, params || {});
    window.dataLayer.push(data);
    if (typeof window.fbq === 'function') {
      if (event === 'generate_lead') window.fbq('track', 'Lead', { content_name: params && params.beneficio });
      else window.fbq('trackCustom', event, params || {});
    }
  }

  var $ = function (s, ctx) { return (ctx || document).querySelector(s); };
  var $$ = function (s, ctx) { return Array.prototype.slice.call((ctx || document).querySelectorAll(s)); };

  var form = $('#form-lead');
  var formSection = $('#formulario');
  var cards = $$('.js-card');
  var radios = $$('input[name="beneficio_escolhido"]');
  var stickyCta = $('#sticky-cta');

  /* ---------- Seleção de benefício (fonte única: os radios do formulário) ---------- */
  function setBeneficio(key, origem) {
    var radio = radios.filter(function (r) { return r.dataset.beneficio === key; })[0];
    if (!radio) return;
    radio.checked = true;
    syncSelection();
    clearError($('#fieldset-beneficio'));
    track('beneficio_selecionado', { beneficio: key, beneficio_nome: BENEFICIOS[key], origem: origem });
  }

  function syncSelection() {
    var checked = radios.filter(function (r) { return r.checked; })[0];
    var key = checked ? checked.dataset.beneficio : null;
    cards.forEach(function (card) {
      var on = card.dataset.beneficio === key;
      card.classList.toggle('is-selected', on);
      card.classList.toggle('is-dimmed', !!key && !on);
      var btn = $('.js-select', card);
      btn.setAttribute('aria-pressed', on ? 'true' : 'false');
      $('.btn__label', btn).textContent = on ? 'Opção selecionada' : 'Quero esta opção';
    });
    radios.forEach(function (r) { r.closest('.choice').classList.toggle('is-checked', r.checked); });
  }

  function goToForm() {
    var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    formSection.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'start' });
    setTimeout(function () {
      var first = $('#nome');
      if (first && !first.value) first.focus({ preventScroll: true });
    }, reduce ? 0 : 600);
  }

  cards.forEach(function (card) {
    // Clique no botão: seleciona e leva ao formulário
    $('.js-select', card).addEventListener('click', function (e) {
      e.stopPropagation();
      setBeneficio(card.dataset.beneficio, 'card_botao');
      goToForm();
    });
    // Clique no card: apenas seleciona
    card.addEventListener('click', function () { setBeneficio(card.dataset.beneficio, 'card'); });
  });

  // Atalhos do painel do hero → seleciona e rola até o card
  $$('.js-hero-option').forEach(function (a) {
    a.addEventListener('click', function () { setBeneficio(a.dataset.beneficio, 'hero'); });
  });

  radios.forEach(function (r) {
    r.addEventListener('change', function () {
      syncSelection();
      clearError($('#fieldset-beneficio'));
      track('beneficio_selecionado', { beneficio: r.dataset.beneficio, beneficio_nome: r.value, origem: 'formulario' });
    });
  });

  // Pré-seleção via URL: ?beneficio=banco_talentos | avaliacao_desempenho | nr1
  var params = new URLSearchParams(window.location.search);
  if (params.get('beneficio') && BENEFICIOS[params.get('beneficio')]) setBeneficio(params.get('beneficio'), 'url');

  /* ---------- Cliques em CTAs ---------- */
  $$('.js-track-cta').forEach(function (el) {
    el.addEventListener('click', function () { track('cta_click', { cta_id: el.id, cta_posicao: el.dataset.cta }); });
  });

  /* ---------- UTMs e URL ---------- */
  ['utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term'].forEach(function (k) {
    var v = params.get(k);
    if (v) $('#' + k).value = v;
  });
  $('#pagina_url').value = window.location.href.split('#')[0];

  /* ---------- Máscara de telefone ---------- */
  var tel = $('#telefone');
  tel.addEventListener('input', function () {
    var d = tel.value.replace(/\D/g, '').slice(0, 11);
    var out = d;
    if (d.length > 10) out = '(' + d.slice(0, 2) + ') ' + d.slice(2, 7) + '-' + d.slice(7);
    else if (d.length > 6) out = '(' + d.slice(0, 2) + ') ' + d.slice(2, 6) + '-' + d.slice(6);
    else if (d.length > 2) out = '(' + d.slice(0, 2) + ') ' + d.slice(2);
    else if (d.length > 0) out = '(' + d;
    tel.value = out;
  });

  /* ---------- Validação ---------- */
  var MSG = {
    beneficio_escolhido: 'Escolha um dos três benefícios.',
    nome: 'Informe seu nome completo.',
    cargo: 'Informe seu cargo.',
    empresa: 'Informe o nome da empresa.',
    telefone: 'Informe um telefone com DDD.',
    email: 'Informe um e-mail válido.',
    quantidade_funcionarios: 'Selecione a quantidade de funcionários.',
    cidade: 'Informe sua cidade.',
    estado: 'Selecione o estado.'
  };

  function setError(group, msg) {
    group.classList.add('is-invalid');
    var err = $('.form__error', group);
    if (err) err.textContent = msg;
    var input = $('.form__input', group);
    if (input) input.setAttribute('aria-invalid', 'true');
  }
  function clearError(group) {
    if (!group) return;
    group.classList.remove('is-invalid');
    var err = $('.form__error', group);
    if (err) err.textContent = '';
    var input = $('.form__input', group);
    if (input) input.removeAttribute('aria-invalid');
  }

  function validateField(name) {
    var group, ok = true, val;
    if (name === 'beneficio_escolhido') {
      group = $('#fieldset-beneficio');
      ok = radios.some(function (r) { return r.checked; });
    } else {
      var el = form.elements[name];
      group = el.closest('.form__group');
      val = (el.value || '').trim();
      if (!val) ok = false;
      else if (name === 'nome') ok = val.length >= 3;
      else if (name === 'email') ok = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(val);
      else if (name === 'telefone') ok = val.replace(/\D/g, '').length >= 10;
    }
    if (ok) clearError(group); else setError(group, MSG[name]);
    return ok;
  }

  var FIELDS = ['beneficio_escolhido', 'nome', 'cargo', 'empresa', 'telefone', 'email', 'quantidade_funcionarios', 'cidade', 'estado'];

  FIELDS.slice(1).forEach(function (name) {
    var el = form.elements[name];
    el.addEventListener('blur', function () { if (el.value) validateField(name); });
    el.addEventListener('input', function () { if (el.closest('.form__group').classList.contains('is-invalid')) validateField(name); });
    el.addEventListener('change', function () { if (el.tagName === 'SELECT') validateField(name); });
  });

  var started = false;
  form.addEventListener('focusin', function () {
    if (!started) { started = true; track('form_start', { form_id: 'form-lead' }); }
  });

  /* ---------- Envio ---------- */
  function collect() {
    var data = {};
    new FormData(form).forEach(function (v, k) { data[k] = typeof v === 'string' ? v.trim() : v; });
    return data;
  }

  function buildRdPayload(data) {
    var p = { conversion_identifier: CONFIG.conversionIdentifier };
    Object.keys(CONFIG.rdFieldMap).forEach(function (k) {
      if (data[k]) p[CONFIG.rdFieldMap[k]] = data[k];
    });
    if (data.utm_source) p.traffic_source = data.utm_source;
    if (data.utm_medium) p.traffic_medium = data.utm_medium;
    if (data.utm_campaign) p.traffic_campaign = data.utm_campaign;
    if (data.utm_term) p.traffic_value = data.utm_term;
    // Base legal (LGPD) — ajuste conforme orientação jurídica da Connectabil
    p.legal_bases = [{ category: 'communications', type: 'legitimate_interest', status: 'granted' }];
    return { event_type: 'CONVERSION', event_family: 'CDP', payload: p };
  }

  function send(data) {
    if (CONFIG.mode === 'rd_api') {
      return fetch(CONFIG.rdEndpoint + encodeURIComponent(CONFIG.rdPublicToken), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', accept: 'application/json' },
        body: JSON.stringify(buildRdPayload(data))
      }).then(function (r) { if (!r.ok) throw new Error('RD ' + r.status); return r; });
    }
    if (CONFIG.mode === 'webhook') {
      return fetch(CONFIG.webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Object.assign({ conversion_identifier: CONFIG.conversionIdentifier }, data))
      }).then(function (r) { if (!r.ok) throw new Error('Webhook ' + r.status); return r; });
    }
    // demo
    console.info('[LP Connectabil] Modo demo — dados que seriam enviados:', data, '\nPayload RD:', buildRdPayload(data));
    return new Promise(function (res) { setTimeout(res, 500); });
  }

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var status = $('#form-status');
    status.textContent = '';

    if (form.elements.website.value) return; // honeypot

    var firstInvalid = null;
    FIELDS.forEach(function (name) {
      if (!validateField(name) && !firstInvalid) firstInvalid = name;
    });
    if (firstInvalid) {
      track('form_erro_validacao', { campo: firstInvalid });
      var target = firstInvalid === 'beneficio_escolhido' ? radios[0] : form.elements[firstInvalid];
      target.focus();
      return;
    }

    var data = collect();
    var key = (radios.filter(function (r) { return r.checked; })[0] || {}).dataset.beneficio;
    var btn = $('#cta-form-submit');
    var label = $('.btn__label', btn);
    btn.disabled = true;
    label.textContent = 'Enviando…';

    send(data).then(function () {
      track('generate_lead', { form_id: 'form-lead', beneficio: key, beneficio_nome: data.beneficio_escolhido, quantidade_funcionarios: data.quantidade_funcionarios, estado: data.estado });
      $('#success-beneficio').textContent = data.beneficio_escolhido;
      form.hidden = true;
      var ok = $('#form-success');
      ok.hidden = false;
      formSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
      ok.focus({ preventScroll: true });
      if (stickyCta) stickyCta.remove();
      $$('#cta-final, #cta-header').forEach(function (b) { b.textContent = 'Ver minha solicitação'; });
    }).catch(function (err) {
      console.error(err);
      track('form_erro_envio', { form_id: 'form-lead' });
      status.textContent = 'Não foi possível enviar agora. Verifique sua conexão e tente novamente.';
      btn.disabled = false;
      label.textContent = 'Quero receber meu benefício';
    });
  });

  /* ---------- Cabeçalho e CTA fixo no celular ---------- */
  var header = $('.site-header');
  var hero = $('.hero');
  var heroOut = false, formIn = false, finalIn = false;
  function updateSticky() {
    if (!stickyCta || !document.body.contains(stickyCta)) return;
    var show = heroOut && !formIn && !finalIn;
    stickyCta.classList.toggle('is-visible', show);
    stickyCta.setAttribute('aria-hidden', show ? 'false' : 'true');
    $('a', stickyCta).tabIndex = show ? 0 : -1;
  }
  if ('IntersectionObserver' in window) {
    new IntersectionObserver(function (en) { heroOut = !en[0].isIntersecting; header.classList.toggle('is-scrolled', heroOut); updateSticky(); }, { threshold: 0.05 }).observe(hero);
    new IntersectionObserver(function (en) { formIn = en[0].isIntersecting; updateSticky(); }, { threshold: 0.05 }).observe(formSection);
    new IntersectionObserver(function (en) { finalIn = en[0].isIntersecting; updateSticky(); }, { threshold: 0.2 }).observe($('#cta-final-section'));
  }

  $('#ano').textContent = new Date().getFullYear();
  track('lp_view', { pagina: 'lp-reboot-contabil-2026' });
})();
