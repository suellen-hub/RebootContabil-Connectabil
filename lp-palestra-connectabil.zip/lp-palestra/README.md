# LP Reboot Contábil 2026 — Connectabil

Landing page de geração de leads para participantes da palestra da CEO, Vitória Oliveira, no Reboot Contábil by RDD (8 e 9/10/2026, Blumenau/SC).
HTML + CSS + JS puro, sem dependências. Funciona em qualquer hospedagem estática (GitHub Pages, Netlify, servidor próprio).

```
index.html              → página (estrutura, copy, SEO, Open Graph)
css/styles.css          → estilos e responsividade (paleta oficial em :root)
js/main.js              → seleção de benefício, validação, envio, tracking
assets/img/             → logo, foto da Vitória, favicon, og-image (1200×630)
assets/fonts/           → Noto Sans auto-hospedada (licença OFL)
```

## Antes de publicar — checklist

| # | O quê | Onde |
|---|---|---|
| 1 | Trocar `SEU-DOMINIO.com.br/palestra/` pela URL final (3 ocorrências) | `index.html` (canonical, og:url, og:image) |
| 2 | Link da Política de Privacidade (`#link-privacidade` e `#link-privacidade-rodape`) | `index.html` |
| 3 | Configurar o envio (modo `rd_api` ou `webhook`) | `js/main.js` → `CONFIG` |
| 4 | Criar no RD os campos personalizados `cf_quantidade_funcionarios` e `cf_beneficio_escolhido` | RD Station |
| 5 | Colar GTM / GA4 / Meta Pixel | `index.html` → bloco "TRACKING" no `<head>` |
| 6 | Validar fonte e cores com o brandbook | `css/styles.css` → `:root` |

## Integração com RD Station

O formulário está em **modo `demo`**: não envia nada, só mostra a tela de sucesso e registra os dados no console (F12).

### Opção A — API de Conversões do RD Station (direto do navegador)
1. RD Station Marketing → Configurações → Integrações → copie o **token público**.
2. Em `js/main.js`: `mode: 'rd_api'` e `rdPublicToken: 'SEU_TOKEN'`.
3. A conversão chega no RD com o identificador `lp-reboot-contabil-2026`.

### Opção B — Webhook (Zapier, Make, n8n, Supabase Edge Function)
`mode: 'webhook'` + `webhookUrl`. A página envia um JSON com todos os campos (nomes da LP) e o seu fluxo repassa para o RD.
Use esta opção se preferir não expor o token público ou quiser enviar o lead também para outro lugar (planilha, CRM, Slack).

### Mapeamento dos campos

| Campo na LP (`name`/`id`) | Campo no RD | Tipo |
|---|---|---|
| `nome` | `name` | padrão |
| `cargo` | `job_title` | padrão |
| `empresa` | `company_name` | padrão |
| `telefone` | `mobile_phone` | padrão |
| `email` | `email` | padrão |
| `cidade` | `city` | padrão |
| `estado` | `state` | padrão (envia a UF) |
| `quantidade_funcionarios` | `cf_quantidade_funcionarios` | **personalizado** |
| `beneficio_escolhido` | `cf_beneficio_escolhido` | **personalizado** |
| `utm_source` / `utm_medium` / `utm_campaign` / `utm_term` | `traffic_source` / `traffic_medium` / `traffic_campaign` / `traffic_value` | padrão |

Para mudar qualquer identificador, edite só `CONFIG.rdFieldMap` em `js/main.js`.

Valores enviados em `beneficio_escolhido` (texto completo, fácil de segmentar no RD):
- `30 dias gratuitos de acesso ao maior banco de talentos contábil do Brasil`
- `1 avaliação de desempenho completa do time da sua empresa`
- `1 diagnóstico + plano de ação de NR-1`

**LGPD:** o payload inclui `legal_bases` como `legitimate_interest` para comunicações. Confirme com o jurídico e ajuste em `buildRdPayload()` se necessário.

## Tracking

Eventos enviados para `window.dataLayer` (prontos para gatilhos no GTM):

| Evento | Quando | Parâmetros |
|---|---|---|
| `lp_view` | página carregou | `pagina` |
| `cta_click` | clique em qualquer CTA | `cta_id`, `cta_posicao` |
| `beneficio_selecionado` | escolheu um benefício | `beneficio`, `beneficio_nome`, `origem` |
| `form_start` | primeiro foco no formulário | `form_id` |
| `form_erro_validacao` | tentou enviar com campo inválido | `campo` |
| `generate_lead` | **conversão** (envio com sucesso) | `beneficio`, `beneficio_nome`, `quantidade_funcionarios`, `estado` |
| `form_erro_envio` | falha no envio | `form_id` |

Se o Meta Pixel estiver instalado (`fbq`), `generate_lead` dispara `Lead` automaticamente.

IDs para tracking: `cta-header`, `cta-hero`, `cta-hero-opcoes`, `beneficio-banco-talentos`, `beneficio-avaliacao-desempenho`, `beneficio-nr1`, `form-lead`, `cta-form-submit`, `cta-final`, `cta-sticky-mobile`, `form-success`.

## Links úteis

- Pré-selecionar um benefício (ex.: QR code no slide): `?beneficio=banco_talentos`, `?beneficio=avaliacao_desempenho` ou `?beneficio=nr1`
- UTMs são capturadas automaticamente: `?utm_source=evento&utm_medium=qrcode&utm_campaign=reboot-contabil-2026`

## SEO sugerido

- **Title:** Benefício exclusivo Reboot Contábil 2026 | Connectabil
- **Meta description:** Participou da palestra de Vitória Oliveira no Reboot Contábil 2026? Escolha uma solução gratuita da Connectabil: 30 dias no Banco de Talentos, avaliação de desempenho do seu time ou diagnóstico de NR-1.

Se a página for exclusiva do evento e você não quiser que apareça no Google, troque `index, follow` por `noindex, follow`.
